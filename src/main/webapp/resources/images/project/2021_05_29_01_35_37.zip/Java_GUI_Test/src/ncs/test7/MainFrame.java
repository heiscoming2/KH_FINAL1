package ncs.test7;

public class MainFrame {
	public static void main(String[] args) {
//		ScoreFrameE tf = new ScoreFrameE();
//		tf.Score();
		new ScoreFrame();
		//new Score();

	}

}
