package ncs.test7;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ScoreFrame {
	public ScoreFrame(){
		JFrame mf = new JFrame();
		
		mf.setBounds(200, 200, 480, 480);
		mf.setTitle("���� 7");
		
		// �г� ����
		JPanel topPanel = new JPanel();
		JPanel panel = new JPanel();
		panel.setSize(480, 480);
		panel.setLayout(null);
		
		// �� ����
		JLabel label = new JLabel("������ �Է��ϼ���");
		label.setFont(new Font("", Font.BOLD, 40));
		
		topPanel.add(label);
		mf.add(topPanel, "North");
		
		//Java �ؽ�Ʈ �ʵ�
		//panel.add(new JLabel("�ڹ�: "));
		JLabel javaScorelb = new JLabel("�ڹ�: ");
		javaScorelb.setSize(50, 30);
		javaScorelb.setLocation(28, 96);
		panel.add(javaScorelb);
		
		JTextField javaScore = new JTextField(10);
		javaScore.setSize(100, 20);
		javaScore.setLocation(60,100);
		panel.add(javaScore);
		//panel.add(javaScore, "North");
		//javaScore.setLocation(50, 100);
		
		//SQL �ؽ�Ʈ �ʵ�	
		//panel.add(new JLabel("SQL: ")); 
		JLabel sqlScorelb = new JLabel("SQL: ");
		sqlScorelb.setSize(50, 30);
		sqlScorelb.setLocation(257, 96);
		panel.add(sqlScorelb);
		
		JTextField sqlScore = new JTextField(10);
		sqlScore.setSize(100, 20);
		sqlScore.setLocation(290,100);
		panel.add(sqlScore);
		//sqlScore.setLocation(150, 100);
		
		// ��ư ����
		JButton calbtn = new JButton("����ϱ�");
		calbtn.setSize(120, 30);
		calbtn.setLocation(160, 200);
		//calbtn.setLocation(100, 230);
		panel.add(calbtn);
				
		//total ��� ����	
		JLabel totallb = new JLabel("���� : ");
		totallb.setSize(50, 20);
		totallb.setLocation(20, 300);
		panel.add(totallb);
		
		JTextField total = new JTextField(10);
		//panel.add(new JLabel("����: "));
		total.setSize(100, 20);
		total.setLocation(60, 300);
		total.setEditable(false); //read only
		panel.add(total);
		//total.setLocation(50, 350);
		
		//average ��� ����
		//panel.add(new JLabel("���: "));
		JLabel averagelb = new JLabel("��� : ");
		averagelb.setSize(50, 20);
		averagelb.setLocation(213, 300);
		panel.add(averagelb);
		
		JTextField average = new JTextField(10);
		average.setSize(100, 20);
		average.setLocation(250, 300);
		average.setEditable(false); //read only
		panel.add(average);
		//average.setLocation(150, 350);

		
		calbtn.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int value = Integer.parseInt(javaScore.getText());
					int value2 = Integer.parseInt(sqlScore.getText());
					total.setText(value + value2 + "");
					average.setText((value + value2)/2 + "");
				} catch (NumberFormatException e1) {
					System.out.println("����");
				}
			}
		});
		
		
		//�����ӿ� �г� ����
		mf.add(panel);
//		mf.add(panel3, BorderLayout.CENTER);
//		mf.add(panel2, BorderLayout.SOUTH);
				
		
		
		mf.setVisible(true);
		mf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
}
